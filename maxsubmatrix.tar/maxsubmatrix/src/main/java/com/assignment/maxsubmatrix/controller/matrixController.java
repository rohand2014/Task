package com.assignment.maxsubmatrix.controller;



import com.assignment.maxsubmatrix.service.matrixService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class matrixController {

    @Autowired
    matrixService ms;


    @RequestMapping(value = "/maxsubmatrix/{matrixDetails}")
    public String getLongestSubMatrix(@PathVariable String[] matrixDetails)
    {

        return ms.inputInitializer(matrixDetails);
    }




}
