package com.assignment.maxsubmatrix.helper;

public class matrixConstructor{

    int R;
    int C;

    public int[][] constructInput(String[] inp) {
        int [][] input={{}};
        int elementsRead=0;
        int size=inp.length;
        R=Integer.parseInt(inp[0]);
        C=Integer.parseInt(inp[1]);


        if(R<=0 || C<=0) {
            System.out.println("Rows:"+R+",Columns:"+C+"input.length:"+input.length);
            return input;
        }

        System.out.println("No.Of Elements:"+size+" Rows:"+R+" Columns:"+C);

        elementsRead=2;
        int i=0,j=0;
        input = new int[R][C];
            while (i < R) {
                j=0;
                while (j < C) {
                    if (elementsRead >= size) break;
                    input[i][j] = Integer.parseInt(inp[elementsRead]);
                    System.out.print(" A[" + i + "][" + j + "]=" + input[i][j] + " ");
                    elementsRead++;
                    j++;
                }
                if(elementsRead >= size) break;
                System.out.print("\n");
                i++;
            }

        return input;
    }

    public  int getR() {

        return R;
    }

    public  int getC() {
        return C;
    }
}