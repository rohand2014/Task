package com.assignment.maxsubmatrix.service;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class matrixServiceTest {

    @Autowired
    private matrixService ms;

    String msg="Longest SubMatrix with ALL 1s has length:2 and height:4";
    int[][] inpMatrix={{0,0,1,1},{1,0,1,1},{1,1,1,1},{0,1,1,1}};
    int[] row = {0,0,0,0};

    @Test
    public void getSubMatrixWithAll1sOfLength2Height4WithGivenNonZeroMatrix(){

        Assert.assertEquals(msg,ms.maxRectangle(4,4,inpMatrix));
    }

    @Test
    public void getRowAreaWithAll0sMatrix(){
        Assert.assertEquals(0,ms.maxHist(1,4,row));
    }

}
