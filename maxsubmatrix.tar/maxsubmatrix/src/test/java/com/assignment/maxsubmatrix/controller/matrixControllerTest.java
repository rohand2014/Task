package com.assignment.maxsubmatrix.controller;

import com.assignment.maxsubmatrix.helper.matrixConstructor;
import com.assignment.maxsubmatrix.service.matrixService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;


@RunWith(SpringRunner.class)
@WebMvcTest(value = matrixController.class, secure = false)
public class matrixControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private matrixService ms;

    String[] matrixDetails={"4","4","0","0","1","1","1","0","1","1","1","1","1","1","0","1","1","1"};

    String SubMatrixWithAll1sWithLength2Height2="Longest SubMatrix with ALL 1s has length:2 and height:4";

    String urlTemplate="/maxsubmatrix/4,4,0,0,1,1,1,0,1,1,1,1,1,1,0,1,1,1";

    @Test
    public void getLongestSubMatrixTest() throws Exception{
       Mockito.when(ms.inputInitializer(matrixDetails)).thenReturn(SubMatrixWithAll1sWithLength2Height2);

        RequestBuilder requestBuilder=MockMvcRequestBuilders.get(urlTemplate);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        Assert.assertEquals(result.getResponse().getContentAsString(),SubMatrixWithAll1sWithLength2Height2);

    }
}
