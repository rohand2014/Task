package com.assignment.maxsubmatrix.helper;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class matrixConstructorTest {

    @Autowired
    private matrixConstructor mac;

    String[] matrixDetails={"4","4","0","0","1","1","1","0","1","1","1","1","1","1","0","1","1","1"};

    String[] matrixDetailsWithInvalidRows={"-1","4","0","0","1","1","1","0","1","1","1","1","1","1","0","1","1","1"};

    int [][] testMatrix;

    @Test
    public void shouldGetEmptyMatrixIfRowOrColumnLessThanEqualToZERO(){
        testMatrix=mac.constructInput(matrixDetailsWithInvalidRows);
        Assert.assertEquals(1,testMatrix.length);
    }

    @Test
    public void ShouldGetProperLengthArrayWithValidInputs(){
        testMatrix=mac.constructInput(matrixDetails);
        for(int i=0;i<testMatrix.length;i++){
            int length=0;
            for(int j=0;j<testMatrix[i].length;j++) length++;
            Assert.assertEquals(length,testMatrix[i].length);
        }
    }

}
