package com.assignment.maxsubmatrix.controller;

import com.assignment.maxsubmatrix.RestapiApplication;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = RestapiApplication.class,webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class matrixControllerIntegrationTest {
    @LocalServerPort
    private int port;

    String uriTemplate="/maxsubmatrix/4,4,0,0,1,1,1,0,1,1,1,1,1,1,0,1,1,1";
    String[] matrixDetails={"4","4","0","0","1","1","1","0","1","1","1","1","1","1","0","1","1","1"};

    String SubMatrixWithAll1sWithLength2Height2="Longest SubMatrix with ALL 1s has length:2 and height:4";

    @Autowired
    private TestRestTemplate testRestTemplate;
    private HttpHeaders headers = new HttpHeaders();

    @Test
    public void getLongestSubMatrixTest(){

        String fulluri="http://localhost:"+port+uriTemplate;
        testRestTemplate.exchange(fulluri,HttpMethod.GET,null,String.class);
        String response=testRestTemplate.getForObject(fulluri,String.class);
        Assert.assertEquals(response,SubMatrixWithAll1sWithLength2Height2);
    }

}
