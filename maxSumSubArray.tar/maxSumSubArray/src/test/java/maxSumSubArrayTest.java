import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.*;

public class maxSumSubArrayTest {

    @Before
    @After
    public void formatting(){
        System.out.println("\n");
    }

    @Test
    public void shouldGetNoSumWithEmptyArray() {

        System.out.println("Running test shouldGetNoSumWithEmptyArray");

        int[] arr = new int[0];

        int actual =maxSumSubArray.maxSubArraySum(arr,0);
        assertEquals(Integer.MIN_VALUE,actual);
    }

    @Test(expected = ArrayIndexOutOfBoundsException.class)
    public void shouldGetBoundsErrorWithIncorrectSize(){

        System.out.println("Running test shouldGetBoundsErrorWithIncorrectSize");

        int[] arr = new int[0];
        int actual =maxSumSubArray.maxSubArraySum(arr,1);

    }

    @Test
    public void shouldGetZeroSumWithAllZeroElementsArray(){

        System.out.println("Running test shouldGetZeroSumWithAllZeroElementsArray");

        int[] arr = {0,0,0,0};
        int actual=maxSumSubArray.maxSubArraySum(arr,arr.length);
        assertTrue(actual ==0);
    }

    @Test
    public void shouldGetNoSumWithAllNegativeElementsArray(){

        System.out.println("Running test shouldGetNoSumWithAllNegativeElementsArray");

        int[] arr = {-1,-2,-3};
        int actual=maxSumSubArray.maxSubArraySum(arr,arr.length);
        int expected=Integer.MIN_VALUE;
        assertEquals(expected,actual);


    }

    @Test
    public void shouldGetPositiveSumWithAtleaseOnePositiveElementInArray(){

        System.out.println("Running test shouldGetPositiveSumWithAtleaseOnePositiveElementInArray");

        int[] arr ={-1,2,-1,0,-2};
        int actual=maxSumSubArray.maxSubArraySum(arr,arr.length);
        assertTrue( actual > 0);

    }

    @Test
    public void shouldGetMaxSumWithLongestSubArray(){

        System.out.println("Running test shouldGetMaxSumWithLongestSubArray");

        int[] arr={-1 ,0, 0, 1 ,-1, 0, 1};
        int rs=maxSumSubArray.maxSubArraySum(arr,arr.length);
        int actual=maxSumSubArray.length;
        int expected=6;
        assertEquals(expected,actual);

    }
}