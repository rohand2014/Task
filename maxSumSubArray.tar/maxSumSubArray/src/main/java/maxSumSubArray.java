import java.util.Scanner;

class maxSumSubArray {

    static int length=0;

    static int maxSubArraySum(int a[], int size)
    {
        length=0;
        if(size==0) return Integer.MIN_VALUE;

        int max = Integer.MIN_VALUE,
                cur_max = 0,start = 0,
                end = 0, s = 0;

        for (int i = 0; i < size; i++)
        {
            cur_max += a[i];

            if (max <= cur_max)
            {
                max = cur_max;
                start = s;
                end = i;
            }

            if (cur_max < 0)
            {
                cur_max = 0;
                s = i + 1;
            }
        }

        if(max>=0){
            length=(end-start)+1;
            System.out.println("Largest SubArray");
            System.out.println("Start index:" + start);
            System.out.println("Length:" + length);
            System.out.println("Sum:" + max);
            System.out.println("Elements: ");

            for(int i=start;i<=end;i++){
                System.out.print(a[i]+" ");
            }
            System.out.print("\n");
        }

        else
            max=Integer.MIN_VALUE;

        return max;
    }

    public static void main(String[] args)
    {
        System.out.print("Enter the Array:");
        Scanner scan= new Scanner(System.in);
        String inp=scan.nextLine();
        String[] items = inp.trim().split(" ");

        int n =items.length;

        int a[] = new int[n];
        int b[] = new int[0];
        for (int i = 0; i <n ; i++) {
            a[i] = Integer.parseInt(items[i]);
        }
        int rs=maxSubArraySum(a,n);

        if(rs==Integer.MIN_VALUE) System.out.println("Sum not possible");
    }
} 